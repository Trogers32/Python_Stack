from django.apps import AppConfig


class BeltConfig(AppConfig):
    name = 'belt'
